<?php

//This is either Success or Failed
 $status = $_POST['status'];

//This is the request id received 
//from the API when the airtime was sent
 $requestId = $_POST['requestId']; 
 
 //Update your records
 //connect to your DB and Store

?>