'use strict';

exports.TEST_ACCOUNT = {
    apiKey: "YOUR_API_KEY",
    username: "YOUR_USERNAME",
    format: "json"
};